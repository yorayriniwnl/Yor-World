# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: public-shell.spec.ts >> direct section anchors and browser Back preserve reachable content
- Location: tests\e2e\public-shell.spec.ts:184:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 200
Received: undefined
```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - link "Skip to content" [ref=f1e2] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=f1e3]:
    - banner [ref=f1e4]:
      - link "Yor World home" [ref=f1e5] [cursor=pointer]:
        - /url: /
        - generic [aria-hidden] [ref=f1e6]: "Y"
        - generic [ref=f1e7]:
          - text: YOR WORLD
          - generic [ref=f1e8]: A studio in progress
      - navigation "Primary navigation" [ref=f1e9]:
        - list [ref=f1e10]:
          - listitem [ref=f1e11]:
            - link "Projects" [ref=f1e12] [cursor=pointer]:
              - /url: /projects
          - listitem [ref=f1e13]:
            - link "About" [ref=f1e14] [cursor=pointer]:
              - /url: /about
          - listitem [ref=f1e15]:
            - link "Contact" [ref=f1e16] [cursor=pointer]:
              - /url: /contact
          - listitem [ref=f1e17]:
            - link "Résumé" [ref=f1e18] [cursor=pointer]:
              - /url: /resume
    - main [ref=f1e19]:
      - generic [ref=f1e20]:
        - paragraph [ref=f1e21]: The person behind the studio
        - heading "About" [level=1] [ref=f1e22]
        - generic [ref=f1e23]:
          - paragraph [ref=f1e24]: Ayush Roy / YOR
          - paragraph [ref=f1e25]: Software engineer — proposed title
          - paragraph [ref=f1e26]: Draft identity. Name and professional title await owner confirmation.
      - generic [ref=f1e27]:
        - generic [ref=f1e28]:
          - heading "Background" [level=2] [ref=f1e29]
          - paragraph [ref=f1e30]: A verified biography is not available yet. This preview does not make claims about employment, education, or project authorship.
        - generic [ref=f1e31]:
          - heading "Skills" [level=2] [ref=f1e32]
          - paragraph [ref=f1e33]: Skills and supporting work are awaiting review. Confirmed examples will be linked here when they are ready.
        - generic [ref=f1e34]:
          - heading "Research & education" [level=2] [ref=f1e35]
          - paragraph [ref=f1e36]: No research, qualifications, or certifications have been verified for publication.
    - contentinfo [ref=f1e37]:
      - paragraph [ref=f1e38]: YOR WORLD / Portfolio preview
      - paragraph [ref=f1e39]: Sound off · Explore at your pace
  - alert [ref=f1e41]
```

# Test source

```ts
  86  |   const scripts: string[] = [];
  87  |   page.on("request", (request) => { if (request.resourceType() === "script") scripts.push(request.url()); });
  88  |   try {
  89  |     for (const [route, heading] of routes) {
  90  |       expect((await page.goto(route))?.status()).toBe(200);
  91  |       await expect(page.getByRole("heading", { level: 1 })).toContainText(heading);
  92  |       expect((await page.reload())?.status()).toBe(200);
  93  |       await expect(page.getByRole("heading", { level: 1 })).toContainText(heading);
  94  |     }
  95  |     await page.goto("/");
  96  |     await page.keyboard.press("Tab");
  97  |     await page.keyboard.press("Enter");
  98  |     await expect(page.getByRole("main")).toBeFocused();
  99  |     await page.locator("summary").click();
  100 |     await expect(page.getByText("The studio is not yet available.", { exact: true })).toBeVisible();
  101 |     await screenshot(page, info, "javascript-disabled");
  102 |     await page.getByRole("navigation").getByRole("link", { name: "Contact", exact: true }).click();
  103 |     await expect(page.getByRole("heading", { name: "Messaging is not available yet." })).toBeVisible();
  104 |     await save(info, "javascript-disabled.json", { scriptsRequested: scripts, routes: routes.map(([route]) => route), navigation: "Contact reached through native link" });
  105 |   } finally { await context.close(); }
  106 | });
  107 | 
  108 | test("world and backend requests blocked; entry reports unavailable; sound and WebGL stay off", async ({ page, baseURL }, info) => {
  109 |   const requested: string[] = [];
  110 |   const blocked: string[] = [];
  111 |   await page.addInitScript(() => {
  112 |     const probe = { webgl: 0, audioContexts: 0, mediaPlay: 0 };
  113 |     Object.assign(window, { __w3Probe: probe });
  114 |     HTMLCanvasElement.prototype.getContext = new Proxy(HTMLCanvasElement.prototype.getContext, {
  115 |       apply(target, thisArg, args) {
  116 |         if (String(args[0]).includes("webgl")) probe.webgl++;
  117 |         return Reflect.apply(target, thisArg, args);
  118 |       },
  119 |     });
  120 |     window.AudioContext = new Proxy(window.AudioContext, {
  121 |       construct(target, args) { probe.audioContexts++; return Reflect.construct(target, args); },
  122 |     });
  123 |     HTMLMediaElement.prototype.play = new Proxy(HTMLMediaElement.prototype.play, {
  124 |       apply(target, thisArg, args) { probe.mediaPlay++; return Reflect.apply(target, thisArg, args); },
  125 |     });
  126 |   });
  127 |   await page.route("**/*", async (route) => {
  128 |     const url = route.request().url();
  129 |     requested.push(url);
  130 |     if (worldPattern.test(url) || new URL(url).origin !== new URL(baseURL!).origin) {
  131 |       blocked.push(url); await route.abort();
  132 |     } else { await route.continue(); }
  133 |   });
  134 |   await page.goto("/");
  135 |   await page.waitForLoadState("networkidle");
  136 |   // Prove the interception guard actually denies both asset and API probes.
  137 |   const guard = await page.evaluate(async () => {
  138 |     const results = [];
  139 |     for (const url of ["/world/__test_probe.glb", "/api/__test_probe"]) {
  140 |       try { await fetch(url); results.push("unexpected response"); } catch { results.push("blocked"); }
  141 |     }
  142 |     return results;
  143 |   });
  144 |   expect(guard).toEqual(["blocked", "blocked"]);
  145 |   await expect(page.getByText("Sound off", { exact: false })).toBeVisible();
  146 |   await page.locator("summary").focus();
  147 |   await page.keyboard.press("Enter");
  148 |   await expect(page.locator("details")).toHaveAttribute("open", "");
  149 |   await expect(page.getByText("The studio is not yet available.", { exact: true })).toBeVisible();
  150 |   await page.waitForLoadState("networkidle");
  151 |   const probe = await page.evaluate(() => (window as unknown as { __w3Probe: object }).__w3Probe);
  152 |   expect(probe).toEqual({ webgl: 0, audioContexts: 0, mediaPlay: 0 });
  153 |   await expect(page.locator("canvas, audio, video")).toHaveCount(0);
  154 |   await screenshot(page, info, "studio-unavailable");
  155 |   await page.keyboard.press("Space");
  156 |   await expect(page.locator("details")).not.toHaveAttribute("open", "");
  157 |   for (const [route, heading] of routes.slice(1)) {
  158 |     await page.goto(route);
  159 |     await expect(page.getByRole("heading", { level: 1 })).toContainText(heading);
  160 |   }
  161 |   const actualWorldOrBackend = requested.filter((url) => worldPattern.test(url) && !url.includes("__test_probe"));
  162 |   expect(actualWorldOrBackend).toEqual([]);
  163 |   expect(blocked.filter((url) => !url.includes("__test_probe"))).toEqual([]);
  164 |   await save(info, "blocked-network.json", { requested, blocked, testInjectedGuard: guard, probe, actualWorldOrBackend });
  165 | });
  166 | 
  167 | test("reduced motion has no active animation or smooth travel and keeps all routes", async ({ page }, info) => {
  168 |   await page.emulateMedia({ reducedMotion: "reduce" });
  169 |   const observations = [];
  170 |   for (const [route, heading] of routes) {
  171 |     await page.goto(route);
  172 |     await expect(page.getByRole("heading", { level: 1 })).toContainText(heading);
  173 |     const observation = await page.evaluate(() => ({
  174 |       reducedMotion: matchMedia("(prefers-reduced-motion: reduce)").matches,
  175 |       activeAnimations: document.getAnimations().length,
  176 |       smoothElements: [...document.querySelectorAll("*")].filter((node) => getComputedStyle(node).scrollBehavior === "smooth").length,
  177 |     }));
  178 |     expect(observation).toEqual({ reducedMotion: true, activeAnimations: 0, smoothElements: 0 });
  179 |     observations.push({ route, ...observation });
  180 |   }
  181 |   await save(info, "reduced-motion.json", observations);
  182 | });
  183 | 
  184 | test("direct section anchors and browser Back preserve reachable content", async ({ page }, info) => {
  185 |   for (const id of ["research", "skills"]) {
> 186 |     expect((await page.goto(`/about#${id}`))?.status()).toBe(200);
      |                                                         ^ Error: expect(received).toBe(expected) // Object.is equality
  187 |     await expect(page.locator(`#${id}`)).toBeInViewport();
  188 |     await page.reload();
  189 |     await expect(page.locator(`#${id}`)).toBeInViewport();
  190 |   }
  191 |   await page.goto("/projects");
  192 |   await page.getByRole("navigation").getByRole("link", { name: "About", exact: true }).click();
  193 |   await expect(page).toHaveURL(/\/about$/);
  194 |   await page.goBack();
  195 |   await expect(page).toHaveURL(/\/projects$/);
  196 |   await expect(page.getByText("0 published projects")).toBeVisible();
  197 |   await save(info, "history.json", { anchors: ["/about#research", "/about#skills"], back: "/projects" });
  198 | });
  199 | 
  200 | test("automated axe scan of every public route and open studio disclosure", async ({ page }, info) => {
  201 |   const scans = [];
  202 |   for (const [route] of routes) {
  203 |     await page.goto(route);
  204 |     if (route === "/") await page.locator("summary").click();
  205 |     const result = await new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"]).analyze();
  206 |     scans.push({ route, violations: result.violations, incomplete: result.incomplete, passes: result.passes.length });
  207 |     expect(result.violations).toEqual([]);
  208 |   }
  209 |   await save(info, "axe.json", { scope: "Automated only; not WCAG certification or screen-reader testing", scans });
  210 | });
  211 | 
  212 | test("mobile, narrow and landscape reflow preserve controls", async ({ page }, info) => {
  213 |   const observations = [];
  214 |   for (const viewport of [{ width: 390, height: 844 }, { width: 320, height: 800 }, { width: 844, height: 390 }]) {
  215 |     await page.setViewportSize(viewport);
  216 |     for (const [route] of routes) {
  217 |       await page.goto(route);
  218 |       const dimensions = await page.evaluate(() => ({ width: innerWidth, scrollWidth: document.documentElement.scrollWidth }));
  219 |       expect(dimensions.scrollWidth).toBeLessThanOrEqual(dimensions.width);
  220 |       const nav = page.getByRole("navigation").getByRole("link");
  221 |       for (const link of await nav.all()) {
  222 |         await expect(link).toBeVisible();
  223 |         const box = await link.boundingBox();
  224 |         expect(box?.height).toBeGreaterThanOrEqual(44);
  225 |       }
  226 |       observations.push({ viewport, route, ...dimensions });
  227 |     }
  228 |     await page.goto("/");
  229 |     await screenshot(page, info, `home-${viewport.width}x${viewport.height}`);
  230 |   }
  231 |   await save(info, "reflow.json", { scope: "Desktop browser viewport emulation; not a physical mobile device or browser zoom test", observations });
  232 | });
  233 | 
```