# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: public-shell.spec.ts >> world and backend requests blocked; entry reports unavailable; sound and WebGL stay off
- Location: tests\e2e\public-shell.spec.ts:108:5

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "http://me.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=ELhb2iGnNSvioMqHRrIHa0XGANBO2JpFqjM23jq5Sh0S0lW1kn6RLF5eGEFF9b6l",
+   "http://me.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=D53AZ3BmSDUkNUgXR2CX_nNZ6974LEVHCHRKad4k1Vg7lXXaWFfL8iWw9JiBfinI",
+   "http://me.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=5nkA9aC2ADt3q2zNl-t0MHYsg1jd11tCB8NC88QREiy8TGbYQXCU8f44wIfpQ9uv",
+   "http://me.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=xdBm7ta7fGLKbgYOs__XSXIPQfV3rJKeovH2UnlAygi3FVwGDvtZEh2zgZqoCaeC",
+   "http://me.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=tloM96Erh-pvB2l5emqdRdnXRTsJpcurPfGHQ8QfHpWRbpDCQf7pnIZKbx8hJRrM",
+ ]
```

# Page snapshot

```yaml
- generic [active] [ref=f4e1]:
  - link "Skip to content" [ref=f4e2] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=f4e3]:
    - banner [ref=f4e4]:
      - link "Yor World home" [ref=f4e5] [cursor=pointer]:
        - /url: /
        - generic [aria-hidden] [ref=f4e6]: "Y"
        - generic [ref=f4e7]:
          - text: YOR WORLD
          - generic [ref=f4e8]: A studio in progress
      - navigation "Primary navigation" [ref=f4e9]:
        - list [ref=f4e10]:
          - listitem [ref=f4e11]:
            - link "Projects" [ref=f4e12] [cursor=pointer]:
              - /url: /projects
          - listitem [ref=f4e13]:
            - link "About" [ref=f4e14] [cursor=pointer]:
              - /url: /about
          - listitem [ref=f4e15]:
            - link "Contact" [ref=f4e16] [cursor=pointer]:
              - /url: /contact
          - listitem [ref=f4e17]:
            - link "Résumé" [ref=f4e18] [cursor=pointer]:
              - /url: /resume
    - main [ref=f4e19]:
      - generic [ref=f4e20]:
        - paragraph [ref=f4e21]: Experience, clearly presented
        - heading "Résumé" [level=1] [ref=f4e22]
        - paragraph [ref=f4e24]: The résumé is awaiting owner confirmation.
      - region [ref=f4e25]:
        - generic [aria-hidden] [ref=f4e26]: ↗
        - generic [ref=f4e27]:
          - heading "No approved résumé is available." [level=2] [ref=f4e28]
          - paragraph [ref=f4e29]: A readable summary and a downloadable document will appear here after the experience, education, and file have been verified.
          - link "Visit About" [ref=f4e30] [cursor=pointer]:
            - /url: /about
            - text: Visit About
            - generic [aria-hidden] [ref=f4e31]: →
    - contentinfo [ref=f4e32]:
      - paragraph [ref=f4e33]: YOR WORLD / Portfolio preview
      - paragraph [ref=f4e34]: Sound off · Explore at your pace
  - alert [ref=f4e36]
```

# Test source

```ts
  63  |   await page.keyboard.press("Enter");
  64  |   await expect(page.getByRole("main")).toBeFocused();
  65  |   await page.keyboard.press("Tab");
  66  |   await expect(page.getByRole("link", { name: "View projects" })).toBeFocused();
  67  |   for (const [index, label] of ["Projects", "About", "Contact", "Résumé"].entries()) {
  68  |     await page.goto("/");
  69  |     // Skip link, home brand, then the four persistent native links.
  70  |     for (let step = 0; step < index + 3; step++) await page.keyboard.press("Tab");
  71  |     const link = page.getByRole("navigation").getByRole("link", { name: label, exact: true });
  72  |     await expect(link).toBeFocused();
  73  |     const outline = await link.evaluate((node) => getComputedStyle(node).outlineStyle);
  74  |     expect(outline).not.toBe("none");
  75  |     sequence.push(await link.getAttribute("href") ?? "missing");
  76  |     await page.keyboard.press("Enter");
  77  |     await expect(page.getByRole("main").getByRole("heading", { level: 1 })).toHaveText(label);
  78  |   }
  79  |   await save(info, "keyboard.json", { skipFocus: "main-content", firstContentLink: "View projects", sequence });
  80  | });
  81  | 
  82  | test("useful HTML and native navigation remain with JavaScript disabled", async ({ browser, baseURL }, info) => {
  83  |   if (!baseURL) throw new Error("The production server baseURL must be configured.");
  84  |   const context = await browser.newContext({ javaScriptEnabled: false, baseURL, viewport: { width: 1440, height: 900 } });
  85  |   const page = await context.newPage();
  86  |   const scripts: string[] = [];
  87  |   page.on("request", (request) => { if (request.resourceType() === "script") scripts.push(request.url()); });
  88  |   try {
  89  |     for (const [route, heading] of routes) {
  90  |       expect((await page.goto(route))?.status()).toBe(200);
  91  |       await expect(page.getByRole("heading", { level: 1 })).toContainText(heading);
  92  |       expect((await page.reload())?.status()).toBe(200);
  93  |       await expect(page.getByRole("heading", { level: 1 })).toContainText(heading);
  94  |     }
  95  |     await page.goto("/");
  96  |     await page.keyboard.press("Tab");
  97  |     await page.keyboard.press("Enter");
  98  |     await expect(page.getByRole("main")).toBeFocused();
  99  |     await page.locator("summary").click();
  100 |     await expect(page.getByText("The studio is not yet available.", { exact: true })).toBeVisible();
  101 |     await screenshot(page, info, "javascript-disabled");
  102 |     await page.getByRole("navigation").getByRole("link", { name: "Contact", exact: true }).click();
  103 |     await expect(page.getByRole("heading", { name: "Messaging is not available yet." })).toBeVisible();
  104 |     await save(info, "javascript-disabled.json", { scriptsRequested: scripts, routes: routes.map(([route]) => route), navigation: "Contact reached through native link" });
  105 |   } finally { await context.close(); }
  106 | });
  107 | 
  108 | test("world and backend requests blocked; entry reports unavailable; sound and WebGL stay off", async ({ page, baseURL }, info) => {
  109 |   const requested: string[] = [];
  110 |   const blocked: string[] = [];
  111 |   await page.addInitScript(() => {
  112 |     const probe = { webgl: 0, audioContexts: 0, mediaPlay: 0 };
  113 |     Object.assign(window, { __w3Probe: probe });
  114 |     HTMLCanvasElement.prototype.getContext = new Proxy(HTMLCanvasElement.prototype.getContext, {
  115 |       apply(target, thisArg, args) {
  116 |         if (String(args[0]).includes("webgl")) probe.webgl++;
  117 |         return Reflect.apply(target, thisArg, args);
  118 |       },
  119 |     });
  120 |     window.AudioContext = new Proxy(window.AudioContext, {
  121 |       construct(target, args) { probe.audioContexts++; return Reflect.construct(target, args); },
  122 |     });
  123 |     HTMLMediaElement.prototype.play = new Proxy(HTMLMediaElement.prototype.play, {
  124 |       apply(target, thisArg, args) { probe.mediaPlay++; return Reflect.apply(target, thisArg, args); },
  125 |     });
  126 |   });
  127 |   await page.route("**/*", async (route) => {
  128 |     const url = route.request().url();
  129 |     requested.push(url);
  130 |     if (worldPattern.test(url) || new URL(url).origin !== new URL(baseURL!).origin) {
  131 |       blocked.push(url); await route.abort();
  132 |     } else { await route.continue(); }
  133 |   });
  134 |   await page.goto("/");
  135 |   await page.waitForLoadState("networkidle");
  136 |   // Prove the interception guard actually denies both asset and API probes.
  137 |   const guard = await page.evaluate(async () => {
  138 |     const results = [];
  139 |     for (const url of ["/world/__test_probe.glb", "/api/__test_probe"]) {
  140 |       try { await fetch(url); results.push("unexpected response"); } catch { results.push("blocked"); }
  141 |     }
  142 |     return results;
  143 |   });
  144 |   expect(guard).toEqual(["blocked", "blocked"]);
  145 |   await expect(page.getByText("Sound off", { exact: false })).toBeVisible();
  146 |   await page.locator("summary").focus();
  147 |   await page.keyboard.press("Enter");
  148 |   await expect(page.locator("details")).toHaveAttribute("open", "");
  149 |   await expect(page.getByText("The studio is not yet available.", { exact: true })).toBeVisible();
  150 |   await page.waitForLoadState("networkidle");
  151 |   const probe = await page.evaluate(() => (window as unknown as { __w3Probe: object }).__w3Probe);
  152 |   expect(probe).toEqual({ webgl: 0, audioContexts: 0, mediaPlay: 0 });
  153 |   await expect(page.locator("canvas, audio, video")).toHaveCount(0);
  154 |   await screenshot(page, info, "studio-unavailable");
  155 |   await page.keyboard.press("Space");
  156 |   await expect(page.locator("details")).not.toHaveAttribute("open", "");
  157 |   for (const [route, heading] of routes.slice(1)) {
  158 |     await page.goto(route);
  159 |     await expect(page.getByRole("heading", { level: 1 })).toContainText(heading);
  160 |   }
  161 |   const actualWorldOrBackend = requested.filter((url) => worldPattern.test(url) && !url.includes("__test_probe"));
  162 |   expect(actualWorldOrBackend).toEqual([]);
> 163 |   expect(blocked.filter((url) => !url.includes("__test_probe"))).toEqual([]);
      |                                                                  ^ Error: expect(received).toEqual(expected) // deep equality
  164 |   await save(info, "blocked-network.json", { requested, blocked, testInjectedGuard: guard, probe, actualWorldOrBackend });
  165 | });
  166 | 
  167 | test("reduced motion has no active animation or smooth travel and keeps all routes", async ({ page }, info) => {
  168 |   await page.emulateMedia({ reducedMotion: "reduce" });
  169 |   const observations = [];
  170 |   for (const [route, heading] of routes) {
  171 |     await page.goto(route);
  172 |     await expect(page.getByRole("heading", { level: 1 })).toContainText(heading);
  173 |     const observation = await page.evaluate(() => ({
  174 |       reducedMotion: matchMedia("(prefers-reduced-motion: reduce)").matches,
  175 |       activeAnimations: document.getAnimations().length,
  176 |       smoothElements: [...document.querySelectorAll("*")].filter((node) => getComputedStyle(node).scrollBehavior === "smooth").length,
  177 |     }));
  178 |     expect(observation).toEqual({ reducedMotion: true, activeAnimations: 0, smoothElements: 0 });
  179 |     observations.push({ route, ...observation });
  180 |   }
  181 |   await save(info, "reduced-motion.json", observations);
  182 | });
  183 | 
  184 | test("direct section anchors and browser Back preserve reachable content", async ({ page }, info) => {
  185 |   for (const id of ["research", "skills"]) {
  186 |     expect((await page.goto(`/about#${id}`))?.status()).toBe(200);
  187 |     await expect(page.locator(`#${id}`)).toBeInViewport();
  188 |     await page.reload();
  189 |     await expect(page.locator(`#${id}`)).toBeInViewport();
  190 |   }
  191 |   await page.goto("/projects");
  192 |   await page.getByRole("navigation").getByRole("link", { name: "About", exact: true }).click();
  193 |   await expect(page).toHaveURL(/\/about$/);
  194 |   await page.goBack();
  195 |   await expect(page).toHaveURL(/\/projects$/);
  196 |   await expect(page.getByText("0 published projects")).toBeVisible();
  197 |   await save(info, "history.json", { anchors: ["/about#research", "/about#skills"], back: "/projects" });
  198 | });
  199 | 
  200 | test("automated axe scan of every public route and open studio disclosure", async ({ page }, info) => {
  201 |   const scans = [];
  202 |   for (const [route] of routes) {
  203 |     await page.goto(route);
  204 |     if (route === "/") await page.locator("summary").click();
  205 |     const result = await new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"]).analyze();
  206 |     scans.push({ route, violations: result.violations, incomplete: result.incomplete, passes: result.passes.length });
  207 |     expect(result.violations).toEqual([]);
  208 |   }
  209 |   await save(info, "axe.json", { scope: "Automated only; not WCAG certification or screen-reader testing", scans });
  210 | });
  211 | 
  212 | test("mobile, narrow and landscape reflow preserve controls", async ({ page }, info) => {
  213 |   const observations = [];
  214 |   for (const viewport of [{ width: 390, height: 844 }, { width: 320, height: 800 }, { width: 844, height: 390 }]) {
  215 |     await page.setViewportSize(viewport);
  216 |     for (const [route] of routes) {
  217 |       await page.goto(route);
  218 |       const dimensions = await page.evaluate(() => ({ width: innerWidth, scrollWidth: document.documentElement.scrollWidth }));
  219 |       expect(dimensions.scrollWidth).toBeLessThanOrEqual(dimensions.width);
  220 |       const nav = page.getByRole("navigation").getByRole("link");
  221 |       for (const link of await nav.all()) {
  222 |         await expect(link).toBeVisible();
  223 |         const box = await link.boundingBox();
  224 |         expect(box?.height).toBeGreaterThanOrEqual(44);
  225 |       }
  226 |       observations.push({ viewport, route, ...dimensions });
  227 |     }
  228 |     await page.goto("/");
  229 |     await screenshot(page, info, `home-${viewport.width}x${viewport.height}`);
  230 |   }
  231 |   await save(info, "reflow.json", { scope: "Desktop browser viewport emulation; not a physical mobile device or browser zoom test", observations });
  232 | });
  233 | 
```