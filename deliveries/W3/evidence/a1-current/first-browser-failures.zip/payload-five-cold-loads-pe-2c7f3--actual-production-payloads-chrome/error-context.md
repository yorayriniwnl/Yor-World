# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: payload.spec.ts >> five cold loads per desktop and mobile profile record actual production payloads
- Location: tests\e2e\payload.spec.ts:7:5

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 26

- Array []
+ Array [
+   Object {
+     "contentEncoding": null,
+     "status": 200,
+     "type": "script",
+     "url": "http://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=wZY_1a4Gdl8UFxdZ1WkMW8tuErbt4PUCghrNJC8yjMS_NmDr_rdZxf_fJ5gU8v66",
+   },
+   Object {
+     "contentEncoding": null,
+     "status": 200,
+     "type": "xhr",
+     "url": "http://gc.kis.v2.scr.kaspersky-labs.com/7D8B79A2-8974-4D7B-A76A-F4F29624C06B9_UKJITP3MXu2JnCArSYIwJvi3mUpg8RsjvAEbfBx32CNmqS05AXf4lQk3wOkC_xtYtA12DkFea9BcPEsi885Q/init?data=eyJ1cmwiOiJodHRwOi8vMTI3LjAuMC4xOjMxNDcvIiwicGx1Z2lucyI6IndzbSZ3bnQmdnMmY2EmcGMmdWEmYWJuJmFibl9zaGFkb3cmY2ImeGhyX2NvbnRlbnQiLCJkYXRhIjp7ImRhdGEiOlt7InBsdWdpbiI6IndzbSIsInBhcmFtZXRlcnMiOiJ7XCJyZWZlcnJlclwiOlwiXCIsXCJzdHViSWRcIjpcIlwifSJ9LHsicGx1Z2luIjoid250IiwicGFyYW1ldGVycyI6IntcInJlZmVycmVyXCI6XCJcIn0ifSx7InBsdWdpbiI6InVhIiwicGFyYW1ldGVycyI6Int9In0seyJwbHVnaW4iOiJhYm4iLCJwYXJhbWV0ZXJzIjoie1wiaXNDc3NVcmxJbmplY3RlZFwiOmZhbHNlfSJ9LHsicGx1Z2luIjoiYWJuX3NoYWRvdyIsInBhcmFtZXRlcnMiOiJ7XCJpc0Nzc1VybEluamVjdGVkXCI6ZmFsc2V9In0seyJwbHVnaW4iOiJ4aHJfY29udGVudCIsInBhcmFtZXRlcnMiOiJ7XCJyZWZlcnJlclwiOlwiXCJ9In1dfSwiaXNUb3BMZXZlbCI6dHJ1ZSwicGFnZVN0YXJ0VGltZSI6MCwibmF2aWdhdGlvblN0YXJ0VGltZSI6MTc5MDc2MDQ0ODUwM30%3D&nocache=1e064&tm=2026-09-30T09%3A27%3A29.721Z",
+   },
+   Object {
+     "contentEncoding": null,
+     "status": 200,
+     "type": "xhr",
+     "url": "http://gc.kis.v2.scr.kaspersky-labs.com/0D6AE064-2E4D-485A-926F-8783A4E4B15F/1362F3F6-4742-425C-84C1-E16BB908214C/to/wsm.sessionActivated?tm=2026-09-30T09%3A27%3A29.843Z",
+   },
+   Object {
+     "contentEncoding": null,
+     "status": 200,
+     "type": "xhr",
+     "url": "http://gc.kis.v2.scr.kaspersky-labs.com/0D6AE064-2E4D-485A-926F-8783A4E4B15F/1362F3F6-4742-425C-84C1-E16BB908214C/to/abn.statInfo?tm=2026-09-30T09%3A27%3A30.353Z",
+   },
+ ]
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | import { mkdir, writeFile, readdir, readFile } from "node:fs/promises";
  3  | import { gzipSync } from "node:zlib";
  4  | import path from "node:path";
  5  | import os from "node:os";
  6  | 
  7  | test("five cold loads per desktop and mobile profile record actual production payloads", async ({ browser, baseURL }, info) => {
  8  |   if (!baseURL) throw new Error("The production server baseURL must be configured.");
  9  |   test.setTimeout(180_000);
  10 |   const runs = [];
  11 |   const profiles = [
  12 |     { name: "desktop", width: 1440, height: 900, dpr: 1.5, downMbps: 10, upMbps: 2, latencyMs: 80 },
  13 |     { name: "mobile-emulated", width: 390, height: 844, dpr: 1.25, downMbps: 4, upMbps: 1, latencyMs: 150 },
  14 |   ];
  15 |   for (const profile of profiles) {
  16 |     for (let run = 1; run <= 5; run++) {
  17 |       const context = await browser.newContext({ baseURL, viewport: { width: profile.width, height: profile.height }, deviceScaleFactor: profile.dpr });
  18 |       try {
  19 |         const page = await context.newPage();
  20 |         const cdp = await context.newCDPSession(page);
  21 |         await cdp.send("Network.enable");
  22 |         await cdp.send("Network.setCacheDisabled", { cacheDisabled: true });
  23 |         await cdp.send("Network.emulateNetworkConditions", {
  24 |           offline: false, latency: profile.latencyMs,
  25 |           downloadThroughput: profile.downMbps * 1_000_000 / 8,
  26 |           uploadThroughput: profile.upMbps * 1_000_000 / 8,
  27 |         });
  28 |         const network: Array<{ url: string; type: string; status: number; contentEncoding: string | null }> = [];
  29 |         page.on("response", (response) => network.push({ url: response.url(), type: response.request().resourceType(),
  30 |           status: response.status(), contentEncoding: response.headers()["content-encoding"] ?? null }));
  31 |         await page.goto("/");
  32 |         await page.waitForLoadState("networkidle");
  33 |         await expect(page.getByRole("heading", { level: 1 })).toContainText("A little world.");
  34 |         const timing = await page.evaluate(() => {
  35 |           const resources = performance.getEntriesByType("resource") as PerformanceResourceTiming[];
  36 |           const navigation = performance.getEntriesByType("navigation") as PerformanceNavigationTiming[];
  37 |           return { userAgent: navigator.userAgent, dpr: devicePixelRatio,
  38 |             navigation: navigation.map((r) => ({ url: r.name, transferSize: r.transferSize, encodedBodySize: r.encodedBodySize, decodedBodySize: r.decodedBodySize, duration: r.duration })),
  39 |             resources: resources.map((r) => ({ url: r.name, initiatorType: r.initiatorType, transferSize: r.transferSize, encodedBodySize: r.encodedBodySize, decodedBodySize: r.decodedBodySize, duration: r.duration })),
  40 |           };
  41 |         });
  42 |         const js = timing.resources.filter((r) => r.initiatorType === "script");
  43 |         const encodedJsBytes = js.reduce((sum, r) => sum + r.encodedBodySize, 0);
  44 |         const totalTransferBytes = [...timing.resources, ...timing.navigation].reduce((sum, r) => sum + r.transferSize, 0);
  45 |         expect(encodedJsBytes).toBeGreaterThan(0);
  46 |         expect(encodedJsBytes).toBeLessThanOrEqual(250 * 1024);
  47 |         expect(totalTransferBytes).toBeLessThanOrEqual(650 * 1024);
> 48 |         expect(network.filter((r) => new URL(r.url).origin !== new URL(baseURL!).origin)).toEqual([]);
     |                                                                                           ^ Error: expect(received).toEqual(expected) // deep equality
  49 |         expect(network.filter((r) => /\.(glb|gltf|wasm|ktx2|mp3|wav|ogg)(\?|$)|\/api\//i.test(r.url))).toEqual([]);
  50 |         runs.push({ profile, run, cache: "cold new context; CDP cache disabled", encodedJsBytes, totalTransferBytes, network, ...timing });
  51 |       } finally { await context.close(); }
  52 |     }
  53 |   }
  54 |   const buildStats = [];
  55 |   // Build inspection complements URL tests, including opaque hashed chunk names.
  56 |   for (const entry of await readdir(".next/static/chunks", { recursive: true, withFileTypes: true })) {
  57 |     if (entry.isFile() && entry.name.endsWith(".js")) {
  58 |       const file = path.join(entry.parentPath, entry.name);
  59 |       const bytes = await readFile(file);
  60 |       const code = bytes.toString("utf8");
  61 |       expect(code).not.toMatch(/WebGLRenderer|THREE\.REVISION|react-three\/fiber|createClient\(.+supabase|Synthetic contribution|testOnly = true/);
  62 |       buildStats.push({ file: path.relative(".next", file), bytes: bytes.length, gzipBytes: gzipSync(bytes).length });
  63 |     }
  64 |   }
  65 |   const destination = path.join(process.env.W3_EVIDENCE_DIR ?? "test-results", info.project.name, "payload.json");
  66 |   await mkdir(path.dirname(destination), { recursive: true });
  67 |   await writeFile(destination, JSON.stringify({
  68 |     scope: "Local next start; CDP throttling. Payload budgets only; no field, GPU, or sustained-device claims.",
  69 |     browser: browser.version(), os: `${os.type()} ${os.release()}`, cpu: os.cpus()[0]?.model,
  70 |     ramBytes: os.totalmem(), tier: "static A1", assetManifestRevision: null, publicationRevision: null,
  71 |     buildId: (await readFile(".next/BUILD_ID", "utf8")).trim(), runs, buildStats,
  72 |   }, null, 2));
  73 | });
  74 | 
```