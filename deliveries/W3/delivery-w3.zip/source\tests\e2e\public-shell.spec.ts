import { test, expect } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";

test.describe("Public Semantic Shell — A1 Foundation", () => {
  test("direct page load and refresh across all semantic public routes", async ({ page }) => {
    const routes = [
      { path: "/", heading: "A little world." },
      { path: "/projects", heading: "Projects" },
      { path: "/about", heading: "About" },
      { path: "/contact", heading: "Contact" },
      { path: "/resume", heading: "Résumé" },
    ];

    for (const { path, heading } of routes) {
      const response = await page.goto(path);
      expect(response?.status()).toBe(200);
      await expect(page.locator("h1")).toContainText(heading);

      // Verify page refresh maintains content
      const reloadResponse = await page.reload();
      expect(reloadResponse?.status()).toBe(200);
      await expect(page.locator("h1")).toContainText(heading);
    }
  });

  test("proves keyboard navigation and skip link functionality", async ({ page }) => {
    // 1. Verify skip link activation transfers focus to #main-content
    await page.goto("/");
    await page.keyboard.press("Tab");
    const skipLink = page.getByRole("link", { name: "Skip to content" });
    await expect(skipLink).toBeFocused();
    await expect(skipLink).toBeVisible();

    await page.keyboard.press("Enter");
    const main = page.locator("#main-content");
    await expect(main).toBeFocused();

    // From #main-content, next Tab enters main actions
    await page.keyboard.press("Tab");
    await expect(page.getByRole("link", { name: "View projects" })).toBeFocused();

    await page.keyboard.press("Tab");
    await expect(page.locator("summary", { hasText: "Enter studio" })).toBeFocused();

    // 2. Verify natural top-to-bottom tab order through primary navigation
    await page.goto("/");
    await page.keyboard.press("Tab"); // skip link
    await page.keyboard.press("Tab"); // brand link
    await expect(page.getByRole("link", { name: "Yor World home" })).toBeFocused();

    await page.keyboard.press("Tab");
    await expect(page.locator("header").getByRole("link", { name: "Projects" })).toBeFocused();

    await page.keyboard.press("Tab");
    await expect(page.locator("header").getByRole("link", { name: "About" })).toBeFocused();

    await page.keyboard.press("Tab");
    await expect(page.locator("header").getByRole("link", { name: "Contact" })).toBeFocused();

    await page.keyboard.press("Tab");
    const resumeLink = page.locator("header").getByRole("link", { name: "Résumé" });
    await expect(resumeLink).toBeFocused();

    // Activate resume link via keyboard Enter
    await page.keyboard.press("Enter");
    await page.waitForURL("**/resume");
    await expect(page.locator("h1")).toContainText("Résumé");
  });

  test("JavaScript-disabled useful content and navigation", async ({ browser }) => {
    const context = await browser.newContext({ javaScriptEnabled: false });
    const page = await context.newPage();

    // Home with JS disabled
    await page.goto("/");
    await expect(page.locator("h1")).toContainText("A little world.");
    await expect(page.getByText("Ayush Roy / YOR")).toBeVisible();
    await expect(page.getByText("Draft identity")).toBeVisible();
    await expect(page.getByRole("link", { name: "View projects" })).toBeVisible();

    // Enter studio disclosure works without JS (native HTML details/summary)
    const studioSummary = page.getByText("Enter studio");
    await expect(studioSummary).toBeVisible();
    await studioSummary.click();
    await expect(page.getByText("The studio is not yet available.")).toBeVisible();

    // Check directory routes with JS disabled
    await page.goto("/projects");
    await expect(page.locator("h1")).toContainText("Projects");
    await expect(page.getByText("0 published projects")).toBeVisible();
    await expect(page.getByText("Case studies are being prepared.")).toBeVisible();

    await page.goto("/about");
    await expect(page.locator("h1")).toContainText("About");
    await expect(page.locator("#skills")).toContainText("Skills");
    await expect(page.locator("#research")).toContainText("Research & education");

    await page.goto("/contact");
    await expect(page.locator("h1")).toContainText("Contact");
    await expect(page.getByText("Messaging is not available yet.")).toBeVisible();
    await expect(page.getByText("No message has been submitted.")).toBeVisible();

    await page.goto("/resume");
    await expect(page.locator("h1")).toContainText("Résumé");
    await expect(page.getByText("No approved résumé is available.")).toBeVisible();

    await context.close();
  });

  test("world requests blocked: no 3D asset requests are ever initiated", async ({ page }) => {
    let intercepted3DRequestCount = 0;

    // Block any 3D asset formats or world endpoints
    await page.route(
      /\.(glb|gltf|bin|hdr|exr)$|(\/world\/|\/three\/|\/r3f\/)/i,
      (route) => {
        intercepted3DRequestCount++;
        route.abort();
      }
    );

    await page.goto("/");
    await expect(page.locator("h1")).toContainText("A little world.");

    // Assert that zero 3D requests were attempted
    expect(intercepted3DRequestCount).toBe(0);

    // Navigate to projects and assert still zero 3D requests
    await page.locator("header").getByRole("link", { name: "Projects" }).click();
    await page.waitForURL("**/projects");
    expect(intercepted3DRequestCount).toBe(0);
  });

  test("no world code or WebGL context fetched before entry", async ({ page }) => {
    const fetchedScripts: string[] = [];
    page.on("request", (req) => {
      if (req.resourceType() === "script") {
        fetchedScripts.push(req.url());
      }
    });

    await page.goto("/");

    // Verify no canvas element is in the DOM
    const canvasCount = await page.locator("canvas").count();
    expect(canvasCount).toBe(0);

    // Verify WebGL was never initialized
    const webglInitialized = await page.evaluate(() => {
      return (window as unknown as { __webglCreated?: boolean }).__webglCreated === true;
    });
    expect(webglInitialized).toBe(false);

    // Verify scripts do not include 3D dependencies
    for (const url of fetchedScripts) {
      expect(url.toLowerCase()).not.toContain("three");
      expect(url.toLowerCase()).not.toContain("fiber");
      expect(url.toLowerCase()).not.toContain("drei");
    }
  });

  test("no backend requirement: works completely statically without external services", async ({ page }) => {
    const failedRequests: string[] = [];
    const appExternalRequests: string[] = [];

    page.on("request", (req) => {
      const url = req.url();
      // Filter out local dev host and local security software injections
      const isLocalHost = url.startsWith("http://127.0.0.1:") || url.startsWith("http://localhost:");
      const isSystemInjection = url.includes("kaspersky-labs.com") || url.startsWith("chrome-extension://");
      if (!isLocalHost && !isSystemInjection) {
        appExternalRequests.push(url);
      }
    });

    page.on("response", (res) => {
      const url = res.url();
      const isSystemInjection = url.includes("kaspersky-labs.com") || url.startsWith("chrome-extension://");
      if (!isSystemInjection && res.status() >= 400) {
        failedRequests.push(`${res.status()} ${url}`);
      }
    });

    await page.goto("/");
    await page.goto("/projects");
    await page.goto("/about");
    await page.goto("/contact");
    await page.goto("/resume");

    // Zero failed requests and zero external service calls initiated by the app
    expect(failedRequests).toEqual([]);
    expect(appExternalRequests).toEqual([]);
  });

  test("audio remains off by default with explicit visual indication", async ({ page }) => {
    await page.goto("/");

    // Verify sound off label in footer
    const footer = page.locator("footer");
    await expect(footer).toContainText("Sound off");

    // Verify no audio elements exist
    const audioCount = await page.locator("audio").count();
    expect(audioCount).toBe(0);

    // Verify AudioContext was not constructed
    const audioContextCreated = await page.evaluate(() => {
      return (window as unknown as { __audioContextCreated?: boolean }).__audioContextCreated === true;
    });
    expect(audioContextCreated).toBe(false);
  });

  test("Enter studio disclosure states that experience is not yet available", async ({ page }) => {
    await page.goto("/");

    const disclosure = page.locator("details");
    await expect(disclosure).not.toHaveAttribute("open", "");

    // Click summary
    await page.getByText("Enter studio").click();
    await expect(disclosure).toHaveAttribute("open", "");
    await expect(page.getByText("The studio is not yet available.")).toBeVisible();
    await expect(
      page.getByText("The room is being made. You can browse the portfolio pages while it takes shape.")
    ).toBeVisible();
  });

  test("respects reduced motion preference", async ({ browser }) => {
    const context = await browser.newContext({ reducedMotion: "reduce" });
    const page = await context.newPage();
    await page.goto("/");

    // Verify media query applies
    const reducedMotionMatches = await page.evaluate(() => {
      return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    });
    expect(reducedMotionMatches).toBe(true);

    await context.close();
  });

  test("meets WCAG 2.2 AA accessibility standards via automated axe audit", async ({ page }) => {
    const routes = ["/", "/projects", "/about", "/contact", "/resume"];

    for (const route of routes) {
      await page.goto(route);
      const accessibilityScanResults = await new AxeBuilder({ page })
        .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
        .analyze();

      expect(accessibilityScanResults.violations).toEqual([]);
    }
  });
});
