import { describe, it, expect } from "vitest";
import {
  ProjectIdSchema,
  EvidenceStatusSchema,
  EvidenceRefSchema,
  ContentSectionSchema,
  PublishedProjectSchema,
  PublicationSchema,
} from "../../src/contracts/content";
import {
  QualityTierSchema,
  PublicRouteSchema,
  CharacterActionSchema,
  CameraIdSchema,
  WorldSnapshotSchema,
  PreferencesSchema,
  defaultPreferences,
  ExperienceIntentSchema,
} from "../../src/contracts/experience";
import { AssetManifestSchema } from "../../src/contracts/assets";
import { publishedProjects, draftIdentity } from "../../src/features/portfolio/public-content";

describe("Content contracts", () => {
  it("validates allowed project IDs", () => {
    expect(ProjectIdSchema.parse("candidatex")).toBe("candidatex");
    expect(ProjectIdSchema.parse("helios")).toBe("helios");
    expect(ProjectIdSchema.parse("zenith")).toBe("zenith");
    expect(ProjectIdSchema.parse("ai-vs-real")).toBe("ai-vs-real");
    expect(ProjectIdSchema.parse("talks")).toBe("talks");
    expect(() => ProjectIdSchema.parse("invalid-id")).toThrow();
  });

  it("validates evidence status values", () => {
    expect(EvidenceStatusSchema.parse("verified")).toBe("verified");
    expect(EvidenceStatusSchema.parse("unknown")).toBe("unknown");
    expect(EvidenceStatusSchema.parse("not-measured")).toBe("not-measured");
    expect(EvidenceStatusSchema.parse("not-applicable")).toBe("not-applicable");
    expect(() => EvidenceStatusSchema.parse("fabricated")).toThrow();
  });

  it("validates evidence reference records", () => {
    const valid = EvidenceRefSchema.parse({
      id: "ev-01",
      kind: "repository",
      url: "https://github.com/example/candidatex",
      checkedAt: "2026-09-30T00:00:00Z",
      status: "verified",
      note: "Public repository checked",
    });
    expect(valid.id).toBe("ev-01");

    // Nullable url/checkedAt allowed when unknown
    const unverified = EvidenceRefSchema.parse({
      id: "ev-02",
      kind: "deployment",
      url: null,
      checkedAt: null,
      status: "unknown",
      note: "Deployment pending confirmation",
    });
    expect(unverified.url).toBeNull();

    // Rejects non-https url
    expect(() =>
      EvidenceRefSchema.parse({
        id: "ev-03",
        kind: "document",
        url: "http://insecure.example.com",
        checkedAt: "2026-09-30T00:00:00Z",
        status: "verified",
        note: "Insecure url",
      })
    ).toThrow();
  });

  it("validates content sections and block types", () => {
    const section = ContentSectionSchema.parse({
      id: "sec-problem",
      heading: "Problem and Scope",
      blocks: [
        { type: "paragraph", text: "Background description of the engineering challenge." },
        { type: "code", language: "typescript", text: "const x = 1;" },
        { type: "list", items: ["Item 1", "Item 2"] },
        { type: "image", mediaId: "img-01", alt: "Architecture diagram", caption: "System boundary" },
      ],
    });
    expect(section.blocks).toHaveLength(4);

    // Rejects empty block text or invalid type
    expect(() =>
      ContentSectionSchema.parse({
        id: "sec-bad",
        heading: "Bad Section",
        blocks: [{ type: "unknown", text: "invalid" }],
      })
    ).toThrow();
  });

  it("validates published project structure", () => {
    const project = PublishedProjectSchema.parse({
      id: "candidatex",
      slug: "candidatex",
      title: "CandidateX",
      summary: "Autonomous candidate evaluation platform.",
      contribution: "Core architecture and evaluation pipelines.",
      sections: [
        {
          id: "intro",
          heading: "Overview",
          blocks: [{ type: "paragraph", text: "Project overview." }],
        },
      ],
      links: [
        {
          label: "Source",
          url: "https://github.com/example/candidatex",
          checkedAt: "2026-09-30T00:00:00Z",
        },
      ],
      evidence: [
        {
          id: "ev-01",
          kind: "repository",
          url: "https://github.com/example/candidatex",
          checkedAt: "2026-09-30T00:00:00Z",
          status: "verified",
          note: "Source verified",
        },
      ],
      revision: 1,
    });
    expect(project.slug).toBe("candidatex");

    // Rejects invalid slug with uppercase or spaces
    expect(() =>
      PublishedProjectSchema.parse({
        ...project,
        slug: "Invalid Slug",
      })
    ).toThrow();
  });

  it("validates publication records", () => {
    const publication = PublicationSchema.parse({
      revision: 1,
      publishedAt: "2026-09-30T04:00:00Z",
      projects: [],
      assetManifestRevision: "am-001",
    });
    expect(publication.revision).toBe(1);
    expect(publication.projects).toHaveLength(0);
  });

  it("ensures public project data remains empty until verified", () => {
    expect(publishedProjects).toEqual([]);
    expect(draftIdentity.name).toBe("Ayush Roy / YOR");
    expect(draftIdentity.role).toContain("proposed title");
  });
});

describe("Experience contracts", () => {
  it("validates quality tiers", () => {
    expect(QualityTierSchema.parse("high")).toBe("high");
    expect(QualityTierSchema.parse("medium")).toBe("medium");
    expect(QualityTierSchema.parse("low")).toBe("low");
    expect(QualityTierSchema.parse("static")).toBe("static");
    expect(() => QualityTierSchema.parse("ultra")).toThrow();
  });

  it("validates public routes", () => {
    const validRoutes = [
      "/",
      "/projects",
      "/about",
      "/about#research",
      "/about#skills",
      "/contact",
      "/resume",
    ];
    for (const route of validRoutes) {
      expect(PublicRouteSchema.parse(route)).toBe(route);
    }
    expect(() => PublicRouteSchema.parse("/unknown")).toThrow();
  });

  it("validates character actions", () => {
    const actions = [
      "coding_idle",
      "mouse_idle",
      "notice_visitor",
      "turn_to_visitor",
      "greeting_nod",
      "return_to_work",
      "attention_glance",
      "breathing_idle",
    ];
    for (const action of actions) {
      expect(CharacterActionSchema.parse(action)).toBe(action);
    }
    expect(() => CharacterActionSchema.parse("run")).toThrow();
  });

  it("validates camera IDs", () => {
    const cameras = [
      "hallway",
      "entry",
      "reveal",
      "greeting",
      "home-desktop",
      "home-mobile",
      "monitor",
      "pc",
      "energy",
      "scanner",
      "microphone",
      "about",
      "contact",
    ];
    for (const camera of cameras) {
      expect(CameraIdSchema.parse(camera)).toBe(camera);
    }
    expect(() => CameraIdSchema.parse("free-cam")).toThrow();
  });

  it("validates world snapshot schema", () => {
    const snap = WorldSnapshotSchema.parse({
      version: 1,
      lampOn: false,
      blindsOpen: true,
      detailFound: false,
    });
    expect(snap.version).toBe(1);
    expect(() => WorldSnapshotSchema.parse({ version: 2, lampOn: true, blindsOpen: true, detailFound: false })).toThrow();
  });

  it("validates preferences schema and sound defaults off", () => {
    expect(defaultPreferences.soundEnabled).toBe(false);
    expect(defaultPreferences.introCompleted).toBe(false);
    expect(defaultPreferences.quality).toBe("auto");
    expect(defaultPreferences.clock24h).toBe(true);

    const custom = PreferencesSchema.parse({
      version: 1,
      introCompleted: true,
      soundEnabled: true,
      quality: "high",
      clock24h: false,
    });
    expect(custom.soundEnabled).toBe(true);
  });

  it("validates experience intents", () => {
    expect(ExperienceIntentSchema.parse({ type: "ENTER", replay: false })).toEqual({ type: "ENTER", replay: false });
    expect(ExperienceIntentSchema.parse({ type: "SKIP" })).toEqual({ type: "SKIP" });
    expect(ExperienceIntentSchema.parse({ type: "GREET" })).toEqual({ type: "GREET" });
    expect(ExperienceIntentSchema.parse({ type: "OPEN_PROJECT", projectId: "candidatex", source: "room" })).toEqual({
      type: "OPEN_PROJECT",
      projectId: "candidatex",
      source: "room",
    });
    expect(
      ExperienceIntentSchema.parse({ type: "NAVIGATE", path: "/projects", source: "dom", camera: null })
    ).toEqual({ type: "NAVIGATE", path: "/projects", source: "dom", camera: null });
    expect(ExperienceIntentSchema.parse({ type: "SET_SOUND", enabled: false })).toEqual({ type: "SET_SOUND", enabled: false });
    expect(ExperienceIntentSchema.parse({ type: "RENDERER_FAILED", code: "CONTEXT_LOST" })).toEqual({
      type: "RENDERER_FAILED",
      code: "CONTEXT_LOST",
    });
    expect(() => ExperienceIntentSchema.parse({ type: "INVALID_INTENT" })).toThrow();
  });
});

describe("Asset contracts", () => {
  it("validates asset manifest schema", () => {
    const manifest = AssetManifestSchema.parse({
      revision: "rev-20260930-01",
      schemaVersion: 1,
      groups: [
        {
          id: "group-a-room-shell",
          tier: "high",
          url: "https://assets.example.com/models/room-shell.glb",
          sha256: "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
          bytes: 4194304,
          triangles: 45000,
          materials: 12,
          estimatedGpuBytes: 16777216,
          clips: ["idle"],
          provenanceId: "prov-w1-001",
          approved: true,
        },
      ],
    });
    expect(manifest.revision).toBe("rev-20260930-01");
    expect(manifest.groups[0]!.triangles).toBe(45000);

    // Rejects sha256 with invalid length
    expect(() =>
      AssetManifestSchema.parse({
        revision: "rev-1",
        schemaVersion: 1,
        groups: [
          {
            ...manifest.groups[0]!,
            sha256: "too-short",
          },
        ],
      })
    ).toThrow();
  });
});
