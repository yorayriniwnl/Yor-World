import { chromium } from "@playwright/test";
import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const PORT = 3133;
const SCREENSHOT_DIR = "C:/Users/yoray/Projects/Yor World/deliveries/W3/evidence/screenshots";
const SUMMARY_FILE = "C:/Users/yoray/Projects/Yor World/deliveries/W3/evidence/payload-summary.json";
const CHROME_PATH = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe";

async function wait(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function isServerReady() {
  try {
    const res = await fetch(`http://127.0.0.1:${PORT}/`);
    return res.status === 200;
  } catch {
    return false;
  }
}

async function main() {
  console.log("Starting server for evidence capture...");
  let serverProcess = null;
  const ready = await isServerReady();
  if (!ready) {
    serverProcess = spawn("pnpm.cmd", ["start", "--port", String(PORT)], {
      cwd: process.cwd(),
      stdio: "pipe",
      shell: true,
      env: { ...process.env, NEXT_TELEMETRY_DISABLED: "1" },
    });
    for (let i = 0; i < 30; i++) {
      if (await isServerReady()) break;
      await wait(500);
    }
  }

  const browser = await chromium.launch({
    executablePath: CHROME_PATH,
    headless: true,
  });

  const page = await browser.newPage({
    viewport: { width: 1440, height: 900 },
  });

  const requests = [];
  page.on("response", async (res) => {
    try {
      const url = res.url();
      if (url.includes("kaspersky-labs.com") || url.startsWith("chrome-extension://")) return;
      const buffer = await res.body().catch(() => null);
      requests.push({
        url,
        status: res.status(),
        contentType: res.headers()["content-type"] || "",
        bytes: buffer ? buffer.length : 0,
      });
    } catch {}
  });

  console.log("Capturing 01-home-desktop.png...");
  await page.goto(`http://127.0.0.1:${PORT}/`, { waitUntil: "networkidle" });
  await page.screenshot({ path: path.join(SCREENSHOT_DIR, "01-home-desktop.png"), fullPage: true });

  console.log("Capturing 02-home-studio-not-available.png...");
  await page.getByText("Enter studio").click();
  await wait(300);
  await page.screenshot({ path: path.join(SCREENSHOT_DIR, "02-home-studio-not-available.png") });

  console.log("Capturing 03-home-keyboard-focus.png...");
  await page.goto(`http://127.0.0.1:${PORT}/`, { waitUntil: "networkidle" });
  await page.keyboard.press("Tab"); // skip link
  await page.keyboard.press("Tab"); // brand
  await page.keyboard.press("Tab"); // projects
  await page.screenshot({ path: path.join(SCREENSHOT_DIR, "03-home-keyboard-focus.png") });

  console.log("Capturing 04-projects.png...");
  await page.goto(`http://127.0.0.1:${PORT}/projects`, { waitUntil: "networkidle" });
  await page.screenshot({ path: path.join(SCREENSHOT_DIR, "04-projects.png"), fullPage: true });

  console.log("Capturing 05-about.png...");
  await page.goto(`http://127.0.0.1:${PORT}/about`, { waitUntil: "networkidle" });
  await page.screenshot({ path: path.join(SCREENSHOT_DIR, "05-about.png"), fullPage: true });

  console.log("Capturing 06-contact.png...");
  await page.goto(`http://127.0.0.1:${PORT}/contact`, { waitUntil: "networkidle" });
  await page.screenshot({ path: path.join(SCREENSHOT_DIR, "06-contact.png"), fullPage: true });

  console.log("Capturing 07-resume.png...");
  await page.goto(`http://127.0.0.1:${PORT}/resume`, { waitUntil: "networkidle" });
  await page.screenshot({ path: path.join(SCREENSHOT_DIR, "07-resume.png"), fullPage: true });

  console.log("Capturing 08-home-mobile.png...");
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(`http://127.0.0.1:${PORT}/`, { waitUntil: "networkidle" });
  await page.screenshot({ path: path.join(SCREENSHOT_DIR, "08-home-mobile.png"), fullPage: true });

  await browser.close();

  if (serverProcess) {
    serverProcess.kill();
  }

  // Calculate payload statistics for the initial home page load
  const homeRequests = requests.filter((r) => r.url === `http://127.0.0.1:${PORT}/` || r.url.includes("/_next/"));
  let htmlBytes = 0;
  let jsBytes = 0;
  let cssBytes = 0;
  let totalBytes = 0;

  for (const r of homeRequests) {
    totalBytes += r.bytes;
    if (r.contentType.includes("html")) htmlBytes += r.bytes;
    else if (r.contentType.includes("javascript")) jsBytes += r.bytes;
    else if (r.contentType.includes("css")) cssBytes += r.bytes;
  }

  const summary = {
    capturedAt: new Date().toISOString(),
    routesCaptured: ["/", "/projects", "/about", "/contact", "/resume"],
    desktopViewport: "1440x900",
    mobileViewport: "390x844",
    initialHomeLoad: {
      totalRequests: homeRequests.length,
      htmlBytes,
      jsBytes,
      cssBytes,
      totalBytes,
      jsCeilingBudgetKiB: 250,
      actualJsKiB: (jsBytes / 1024).toFixed(2),
      passJsBudget: jsBytes <= 250 * 1024,
      totalTransferCeilingKiB: 650,
      actualTotalKiB: (totalBytes / 1024).toFixed(2),
      passTotalBudget: totalBytes <= 650 * 1024,
    },
    requests: homeRequests,
  };

  fs.writeFileSync(SUMMARY_FILE, JSON.stringify(summary, null, 2), "utf8");
  console.log("Evidence capture complete! Summary:", JSON.stringify(summary.initialHomeLoad, null, 2));
}

main().catch((err) => {
  console.error("Error in evidence capture:", err);
  process.exit(1);
});
