// deliveries/W2/playback/validate-gltf.js
// Automated glTF validation for avatar-proof.glb and fixture-proof.glb
const fs = require('fs');
const path = require('path');

// Locate gltf-validator: check temp dependency root or local node_modules
const tempPath = fs.readFileSync(path.resolve(__dirname, '../evidence/dependency-temp-path.txt'), 'utf8').trim();
let validator;
try {
  validator = require(path.join(tempPath, 'node_modules/gltf-validator'));
} catch (e1) {
  try {
    validator = require('gltf-validator');
  } catch (e2) {
    console.error('ERROR: Could not locate gltf-validator. Please run npm install in temp dir.');
    process.exit(1);
  }
}

const W2_ROOT = path.resolve(__dirname, '..');
const EVIDENCE_DIR = path.join(W2_ROOT, 'evidence');

async function validateGlb(filename) {
  const filePath = path.join(W2_ROOT, filename);
  if (!fs.existsSync(filePath)) {
    throw new Error(`File not found: ${filePath}`);
  }
  const buffer = fs.readFileSync(filePath);
  const report = await validator.validateBytes(new Uint8Array(buffer), {
    maxIssues: 100,
    ignoredIssues: []
  });
  return {
    filename,
    bytes: buffer.length,
    numErrors: report.issues.numErrors,
    numWarnings: report.issues.numWarnings,
    numInfos: report.issues.numInfos,
    numHints: report.issues.numHints,
    messages: report.issues.messages,
    info: {
      version: report.info.version,
      generator: report.info.generator,
      drawCallCount: report.info.drawCallCount,
      animationCount: report.info.animationCount,
      materialCount: report.info.materialCount,
      totalVertexCount: report.info.totalVertexCount,
      totalTriangleCount: report.info.totalTriangleCount
    }
  };
}

async function run() {
  console.log('[W2 glTF Validation] Starting validation...');
  const avatarReport = await validateGlb('avatar-proof.glb');
  const fixtureReport = await validateGlb('fixture-proof.glb');

  const combined = {
    timestamp: new Date().toISOString(),
    validatorVersion: '2.0.0-dev.3.10',
    avatar: avatarReport,
    fixture: fixtureReport
  };

  const outPath = path.join(EVIDENCE_DIR, 'gltf-validation.json');
  fs.writeFileSync(outPath, JSON.stringify(combined, null, 2));
  console.log(`[W2 glTF Validation] Validation report written to ${outPath}`);
  console.log(`  avatar-proof.glb: errors=${avatarReport.numErrors}, warnings=${avatarReport.numWarnings}, infos=${avatarReport.numInfos}`);
  console.log(`  fixture-proof.glb: errors=${fixtureReport.numErrors}, warnings=${fixtureReport.numWarnings}, infos=${fixtureReport.numInfos}`);

  if (avatarReport.numErrors > 0 || fixtureReport.numErrors > 0) {
    console.error('[W2 glTF Validation] FAILED: Errors found during validation.');
    process.exit(1);
  } else {
    console.log('[W2 glTF Validation] PASS: 0 errors in exported glTF binaries.');
  }
}

run().catch(err => {
  console.error('[W2 glTF Validation] Error:', err);
  process.exit(1);
});
