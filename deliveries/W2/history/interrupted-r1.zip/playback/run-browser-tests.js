// deliveries/W2/playback/run-browser-tests.js
// Automated headless browser playback validation using Playwright against installed system browsers.
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const { startServer } = require('./serve');

// Locate playwright from temp dependency root or local node_modules
const tempPath = fs.readFileSync(path.resolve(__dirname, '../evidence/dependency-temp-path.txt'), 'utf8').trim();
let playwright;
try {
  playwright = require(path.join(tempPath, 'node_modules/playwright'));
} catch (e1) {
  try {
    playwright = require('playwright');
  } catch (e2) {
    console.error('ERROR: Could not locate Playwright. Please ensure it is installed in temp dir.');
    process.exit(1);
  }
}

const W2_ROOT = path.resolve(__dirname, '..');
const EVIDENCE_DIR = path.join(W2_ROOT, 'evidence');

async function launchBrowser() {
  const channels = ['chrome', 'msedge'];
  for (const channel of channels) {
    try {
      console.log(`[Browser Test] Attempting launch with channel "${channel}"...`);
      const browser = await playwright.chromium.launch({
        channel,
        headless: true,
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage',
          '--use-gl=angle',
          '--use-angle=d3d11',
          '--enable-webgl'
        ]
      });
      console.log(`[Browser Test] Launched browser with channel "${channel}" (version: ${browser.version()})`);
      return { browser, channel, version: browser.version() };
    } catch (err) {
      console.warn(`[Browser Test] Channel "${channel}" launch failed: ${err.message}`);
    }
  }
  throw new Error('No system browser (Chrome or Edge) could be launched via Playwright.');
}

async function run() {
  const logEntries = [];
  function log(msg) {
    const ts = new Date().toISOString();
    const entry = `[${ts}] ${msg}`;
    console.log(entry);
    logEntries.push(entry);
  }

  log('Starting W2 browser playback verification suite...');

  // 1. Start HTTP server
  const serverInfo = await startServer(0);
  log(`Local test server started at ${serverInfo.url} (port ${serverInfo.port})`);

  // 2. Launch browser
  const { browser, channel, version } = await launchBrowser();
  log(`Connected to headless browser: channel=${channel}, version=${version}`);

  const context = await browser.newContext({
    viewport: { width: 1280, height: 720 },
    deviceScaleFactor: 1
  });
  const page = await context.newPage();

  page.on('response', resp => {
    if (!resp.ok()) log(`[HTTP ${resp.status()}] ${resp.url()}`);
  });

  page.on('console', msg => {
    log(`[Browser Console] [${msg.type()}] ${msg.text()}`);
  });

  page.on('pageerror', err => {
    log(`[Browser Error] ${err.message}`);
  });

  // 3. Navigate to harness
  log(`Navigating to ${serverInfo.url}...`);
  await page.goto(serverInfo.url, { waitUntil: 'networkidle' });

  // 4. Wait for harness ready
  log('Waiting for models and Three.js initialization...');
  await page.waitForFunction(() => window.__W2_HARNESS__ && window.__W2_HARNESS__.isLoaded(), { timeout: 15000 });
  log('Three.js harness successfully initialized and models loaded.');

  // Let initial frame render
  await page.waitForTimeout(500);

  const measurements = {
    testTimestamp: new Date().toISOString(),
    browser: { channel, version },
    serverUrl: serverInfo.url,
    clipsTested: [],
    repeatedTest: null,
    interruptionTest: null,
    screenCaptures: {}
  };

  // 5. Test coding_idle
  log('Testing clip: coding_idle...');
  await page.evaluate(() => window.__W2_HARNESS__.playClip('coding_idle', 0));
  await page.waitForTimeout(800);
  const codingDiag = await page.evaluate(() => window.__W2_HARNESS__.getDiagnostics());
  log(`coding_idle metrics: rootPos=${JSON.stringify(codingDiag.rootPosition)}, drift=${codingDiag.rootDrift}m, chairYaw=${codingDiag.chairYawDeg}°`);
  measurements.clipsTested.push({ clip: 'coding_idle', ...codingDiag });

  // Capture coding screenshot
  const codingShotPath = path.join(EVIDENCE_DIR, 'browser-coding.png');
  await page.screenshot({ path: codingShotPath });
  measurements.screenCaptures.coding = 'evidence/browser-coding.png';
  log(`Saved screenshot: ${codingShotPath}`);

  // 6. Test notice_visitor (hands clear)
  log('Testing clip: notice_visitor...');
  await page.evaluate(() => window.__W2_HARNESS__.playClip('notice_visitor', 0.15));
  await page.waitForTimeout(650);
  const noticeDiag = await page.evaluate(() => window.__W2_HARNESS__.getDiagnostics());
  log(`notice_visitor metrics: rootPos=${JSON.stringify(noticeDiag.rootPosition)}, drift=${noticeDiag.rootDrift}m`);
  measurements.clipsTested.push({ clip: 'notice_visitor', ...noticeDiag });

  const handsClearShotPath = path.join(EVIDENCE_DIR, 'browser-hands-clear.png');
  await page.screenshot({ path: handsClearShotPath });
  measurements.screenCaptures.handsClear = 'evidence/browser-hands-clear.png';
  log(`Saved screenshot: ${handsClearShotPath}`);

  // 7. Test turn_to_visitor and greeting_nod
  log('Testing clip: turn_to_visitor...');
  await page.evaluate(() => window.__W2_HARNESS__.playClip('turn_to_visitor', 0.2));
  await page.waitForTimeout(1300);
  const turnDiag = await page.evaluate(() => window.__W2_HARNESS__.getDiagnostics());
  log(`turn_to_visitor metrics: chairYaw=${turnDiag.chairYawDeg}°, drift=${turnDiag.rootDrift}m`);
  measurements.clipsTested.push({ clip: 'turn_to_visitor', ...turnDiag });

  log('Testing clip: greeting_nod...');
  await page.evaluate(() => window.__W2_HARNESS__.playClip('greeting_nod', 0.15));
  await page.waitForTimeout(950);
  const greetingDiag = await page.evaluate(() => window.__W2_HARNESS__.getDiagnostics());
  log(`greeting_nod metrics: chairYaw=${greetingDiag.chairYawDeg}°, drift=${greetingDiag.rootDrift}m`);
  measurements.clipsTested.push({ clip: 'greeting_nod', ...greetingDiag });

  const greetingShotPath = path.join(EVIDENCE_DIR, 'browser-greeting.png');
  await page.screenshot({ path: greetingShotPath });
  measurements.screenCaptures.greeting = 'evidence/browser-greeting.png';
  log(`Saved screenshot: ${greetingShotPath}`);

  // 8. Test return_to_work
  log('Testing clip: return_to_work...');
  await page.evaluate(() => window.__W2_HARNESS__.playClip('return_to_work', 0.2));
  await page.waitForTimeout(1400);
  const returnDiag = await page.evaluate(() => window.__W2_HARNESS__.getDiagnostics());
  log(`return_to_work metrics: chairYaw=${returnDiag.chairYawDeg}°, drift=${returnDiag.rootDrift}m`);
  measurements.clipsTested.push({ clip: 'return_to_work', ...returnDiag });

  // 9. Test Interruption to Safe Pose
  log('Testing Interruption: triggering turn and interrupting midway (at ~400ms)...');
  await page.evaluate(() => window.__W2_HARNESS__.playClip('turn_to_visitor', 0.1));
  await page.waitForTimeout(400);
  const midTurnDiag = await page.evaluate(() => window.__W2_HARNESS__.getDiagnostics());
  log(`Mid-turn snapshot: chairYaw=${midTurnDiag.chairYawDeg}°`);

  await page.evaluate(() => window.__W2_HARNESS__.interruptToSafePose());
  log('Interrupt triggered. Waiting for return transition...');
  await page.waitForTimeout(1500);

  const interruptedDiag = await page.evaluate(() => window.__W2_HARNESS__.getDiagnostics());
  log(`Post-interruption metrics: clip=${interruptedDiag.currentClip}, chairYaw=${interruptedDiag.chairYawDeg}°, drift=${interruptedDiag.rootDrift}m`);
  measurements.interruptionTest = {
    midTurnYawDeg: midTurnDiag.chairYawDeg,
    finalClip: interruptedDiag.currentClip,
    finalYawDeg: interruptedDiag.chairYawDeg,
    finalRootDriftM: interruptedDiag.rootDrift,
    settledSafely: Math.abs(interruptedDiag.chairYawDeg) < 5.0 && interruptedDiag.rootDrift < 0.001
  };

  const interruptedShotPath = path.join(EVIDENCE_DIR, 'browser-interrupted.png');
  await page.screenshot({ path: interruptedShotPath });
  measurements.screenCaptures.interrupted = 'evidence/browser-interrupted.png';
  log(`Saved screenshot: ${interruptedShotPath}`);

  // 10. Test Repeated Turn/Return Test (5 cycles)
  log('Running 5 repeated turn/return cycles...');
  const repeatedResult = await page.evaluate(async () => {
    return await window.__W2_HARNESS__.runRepeatedTest(5);
  });
  log(`Repeated test completed: ${JSON.stringify(repeatedResult)}`);
  const finalDiag = await page.evaluate(() => window.__W2_HARNESS__.getDiagnostics());
  measurements.repeatedTest = {
    cycles: 5,
    maxDriftM: repeatedResult.maxDrift,
    finalDriftM: finalDiag.rootDrift,
    finalRootPosition: finalDiag.rootPosition,
    pass: repeatedResult.maxDrift < 0.001
  };

  // 11. Capture Frame Sequence for Animated Demonstration GIF
  log('Capturing frame sequence during visitor sequence for animated demonstration...');
  const framesDir = path.join(EVIDENCE_DIR, 'frames_temp');
  if (!fs.existsSync(framesDir)) fs.mkdirSync(framesDir, { recursive: true });

  await page.evaluate(() => window.__W2_HARNESS__.playClip('coding_idle', 0));
  await page.waitForTimeout(300);

  const framePaths = [];
  const captureSteps = [
    { clip: 'coding_idle', frames: 4, delayMs: 150 },
    { clip: 'notice_visitor', frames: 4, delayMs: 150 },
    { clip: 'turn_to_visitor', frames: 8, delayMs: 150 },
    { clip: 'greeting_nod', frames: 6, delayMs: 150 },
    { clip: 'return_to_work', frames: 8, delayMs: 160 },
    { clip: 'coding_idle', frames: 4, delayMs: 150 }
  ];

  let frameIdx = 0;
  for (const step of captureSteps) {
    await page.evaluate(c => window.__W2_HARNESS__.playClip(c, 0.15), step.clip);
    for (let f = 0; f < step.frames; f++) {
      await page.waitForTimeout(step.delayMs);
      const fPath = path.join(framesDir, `frame_${String(frameIdx).padStart(3, '0')}.png`);
      await page.screenshot({ path: fPath });
      framePaths.push(fPath);
      frameIdx++;
    }
  }
  log(`Captured ${framePaths.length} animation frames.`);

  // Clean up browser and server
  await browser.close();
  serverInfo.server.close();
  log('Browser and local test server closed.');

  // Write measurements and logs
  fs.writeFileSync(path.join(EVIDENCE_DIR, 'browser-measurements.json'), JSON.stringify(measurements, null, 2));
  fs.writeFileSync(path.join(EVIDENCE_DIR, 'browser-playback.log'), logEntries.join('\n'));
  log('Wrote browser-measurements.json and browser-playback.log.');

  // 12. Compile GIF using Python Pillow
  log('Compiling frames into animated GIF via Python Pillow...');
  const pyScript = `
import sys
from pathlib import Path
from PIL import Image

frames_dir = Path(r"${framesDir.replace(/\\/g, '/')}")
out_gif = Path(r"${path.join(EVIDENCE_DIR, 'browser-playback.gif').replace(/\\/g, '/')}")
frames = []
for p in sorted(frames_dir.glob("frame_*.png")):
    img = Image.open(p).convert("RGB")
    # Resize to modest resolution for compact evidence file
    img = img.resize((640, 360), Image.Resampling.LANCZOS)
    frames.append(img)

if frames:
    frames[0].save(out_gif, save_all=True, append_images=frames[1:], duration=150, loop=0, optimize=True)
    print(f"GIF_OK: {out_gif} ({out_gif.stat().st_size} bytes, {len(frames)} frames)")
else:
    print("NO_FRAMES")
`;

  const py = spawn('python', ['-c', pyScript]);
  let pyOut = '';
  py.stdout.on('data', d => { pyOut += d; });
  py.stderr.on('data', d => { pyOut += d; });
  py.on('close', code => {
    log(`Python GIF compiler output (exit ${code}): ${pyOut.trim()}`);
    // Clean up temporary frames
    try {
      for (const p of framePaths) fs.unlinkSync(p);
      fs.rmdirSync(framesDir);
      log('Temporary frame files cleaned up.');
    } catch (e) {
      log(`Frame cleanup warning: ${e.message}`);
    }
    log('=== BROWSER PLAYBACK VERIFICATION COMPLETE ===');
  });
}

run().catch(err => {
  console.error('[Browser Test Fatal Error]', err);
  process.exit(1);
});
